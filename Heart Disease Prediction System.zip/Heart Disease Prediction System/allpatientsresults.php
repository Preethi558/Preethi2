<?php 

	$con = mysqli_connect("localhost","root","","heart_disease_prediction_system");
?>

<hr>


	<!doctype html>
	<html lang="en">
	  <head>
	    <title>View Data</title>
	  </head>
	  <body onload="ReplaceResult()">

		
<div class="col-lg-12 text-center">
	<div><span style="color: blue;">Blue</span> color to the table represents the elements of examinations which are <b>below</b> the <b>minimum</b> valid value.</div>
	<div><span style="color: red;">Red</span> color to the table represents the elements of examinations which are <b>above</b> the <b>maximum</b> valid value.</div>
</div>


<div class="table_exams_div" id="table_exams">
<h2>Results of examinations</h2>
<table class="table table-bordered table-responsive" >
  <thead>
    <tr>
<th scope="fit" style="background-color: #C43838; color: white;">Username</th>
<th scope="fit" style="background-color: #C43838; color: white;">Doctor</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Chest Pain Type</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Resting Blood Pressure</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Serum Cholestrol</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Fasting Blood sugar</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Resting Electro<br>cardiogra<br>phic</th>
      <th scope="fit" style="background-color: #C43838; color: white;">ST-T wave abnormality</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Ventricular hypertrophy</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Maximum Heart Rate</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Oldpeak</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Vessels by flourosopy</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Thal</th>
      <th scope="fit" style="background-color: #C43838; color: white;">Result</th>
    </tr>
  </thead>
  <tbody id="data_of_table">
  	<?php
	$query="SELECT * FROM patientsdata ORDER BY age ASC";
	$result = mysqli_query($con,$query);
	while($row = mysqli_fetch_assoc($result)) 
	{
$username=$row["username"];

$doctor=$row["doctor"];
		$cp = $row["cp"];
		$trestbps = $row["trestbps"];
		$chol = $row["chol"];
		$fbs = $row["fbs"];
		$restecg = $row["restecg"];
		$thalach = $row["thalach"];
		$exang = $row["exang"];
		$oldpeak = $row["oldpeak"];
		$slope = $row["slope"];
		$ca = $row["ca"];
		$thal = $row["thal"];

	?>
    <tr>
<td><?php echo $row["username"];?></td>
<td><?php echo $row["doctor"];?></td>
      <td class="fit cp_id"><?php echo $row["cp"]; ?></td>
      <td class="fit trestbps_id"><?php echo $row["trestbps"]; ?></td>
      <td class="fit chol_id"><?php echo $row["chol"]; ?></td>
      <td class="fit fbs_id" ><?php echo $row["fbs"]; ?></td>
      <td class="fit restecg_id" ><?php echo $row["restecg"]; ?></td>
	  <td class="fit slope_id" ><?php echo $row["slope"]; ?></td>
	  <td class="fit exang_id"><?php echo $row["exang"]; ?></td>
	  <td class="fit thalach_id"><?php echo $row["thalach"]; ?></td>
      <td class="fit oldpeak_id" ><?php echo $row["oldpeak"]; ?></td>
      <td class="fit ca_id" ><?php echo $row["ca"]; ?></td>
      <td class="fit thal_id" ><?php echo $row["thal"]; ?></td>
      <td class="fit value_of_result" ><?php echo $row["result"]; ?><span id="result_replace"></span></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>


<?php
$query="SELECT username,doctor,min_rest, max_rest, min_cholesterol, max_cholesterol, min_heartrate, max_heartrate, min_oldpeak, max_oldpeak, min_vessels, max_vessels, min_thal, max_thal FROM patientsdata WHERE username = '".$_SESSION['username']."' ORDER BY age ASC";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) 
{
$username = $row['username'];
$doctor = $row['doctor'];	
$min_rest = $row['min_rest'];
	$max_rest = $row['max_rest'];
	$min_cholesterol = $row['min_cholesterol'];
	$max_cholesterol = $row['max_cholesterol'];
	$min_heartrate = $row['min_heartrate'];
	$max_heartrate = $row['max_heartrate'];
	$min_oldpeak = $row['min_oldpeak'];
	$max_oldpeak = $row['max_oldpeak'];
	$min_vessels = $row['min_vessels'];
	$max_vessels = $row['max_vessels'];
	$min_thal = $row['min_thal'];
	$max_thal = $row['max_thal'];

}

if($trestbps < $min_rest) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[1].style.color = "blue"';
	echo '</script>';
}
if($trestbps >= $max_rest)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[1].style.color = "red"';
	echo '</script>';
}
if($chol < $min_cholesterol) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[2].style.color = "blue"';
	echo '</script>';
}
if($chol >= $max_cholesterol)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[2].style.color = "red"';
	echo '</script>';
}
if($thalach < $min_heartrate) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[7].style.color = "blue"';
	echo '</script>';
}
if($thalach >= $max_heartrate)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[7].style.color = "red"';
	echo '</script>';
}
if($oldpeak < $min_oldpeak) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[8].style.color = "blue"';
	echo '</script>';
}
if($oldpeak >= $max_oldpeak)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[8].style.color = "red"';
	echo '</script>';
}
if($ca < $min_vessels) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[9].style.color = "blue"';
	echo '</script>';
}
if($ca >= $max_vessels)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[9].style.color = "red"';
	echo '</script>';
}
if($thal < $min_thal) 
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[10].style.color = "blue"';
	echo '</script>';
}
if($thal >= $max_thal)
{
	echo '<script>';
	echo 'document.getElementById("data_of_table").lastElementChild.cells[10].style.color = "red"';
	echo '</script>';
}

?>
<br><br>


	

<script>
// When the user scrolls down 50px from the top of the document, resize the header's font size
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("navigation_bar").style.fontSize = "21px";
    document.getElementById("navigation_bar").style.paddingTop = "0px";
  } else {
    document.getElementById("navigation_bar").style.fontSize = "20px";
    document.getElementById("navigation_bar").style.paddingTop = "5px";
  }
}

</script>


		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

		<script src="js/numscroller-1.0.js"></script>
		
	    <!-- Optional JavaScript -->
	    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	  	

	  </body>
	</html>