<?php 
	define('EMAIL', 'hdpsemail@gmail.com');
	define('PASS', 'hdps12345');
 ?>